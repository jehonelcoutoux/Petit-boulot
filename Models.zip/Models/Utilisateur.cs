﻿namespace PtiBoulot.Models
{
    public class Utilisateur
    {
        public int Id { get; set; }
        public string NomComplet { get; set; } = "";
        public string Email { get; set; } = "";
        public string MotDePasse { get; set; } = "";
        public string Role { get; set; } = ""; 
        public string? Telephone { get; set; }
        public string? Ville { get; set; }
        public string? Competences { get; set; }
        public decimal? TarifHoraire { get; set; }
        public string? DescriptionProfil { get; set; }

        public string Initiales => NomComplet.Length >= 2
            ? $"{NomComplet[0]}{NomComplet.Split(' ').Last()[0]}".ToUpper()
            : NomComplet[0].ToString().ToUpper();
    }

    public class Offre
    {
        public int Id { get; set; }
        public string Titre { get; set; } = "";
        public string Description { get; set; } = "";
        public decimal Budget { get; set; }
        public string? Delai { get; set; }
        public string? Localisation { get; set; }
        public string? Statut { get; set; }
        public int ClientId { get; set; }

        public Utilisateur? Client { get; set; }
        public ICollection<Candidature> Candidatures { get; set; } = new List<Candidature>();
    }

    public class Candidature
    {
        public int Id { get; set; }
        public int OffreId { get; set; }
        public int PrestataireId { get; set; }
        public string? StatutCandidature { get; set; }

        public Offre? Offre { get; set; }
        public Utilisateur? Prestataire { get; set; }
    }
    public class Notification
    {
        public int Id { get; set; }
        public int UtilisateurId { get; set; }
        public string Message { get; set; } = "";
        public bool EstLue { get; set; } = false;
        public DateTime DateCreation { get; set; } = DateTime.Now;

        public Utilisateur? Utilisateur { get; set; }
    }
}
﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using PtiBoulot.Models;
using PtiBoulot.Services;

namespace PtiBoulot.Pages
{
    public class NotificationViewModel
    {
        public int Id { get; set; }
        public string Message { get; set; } = "";
        public string DateStr { get; set; } = "";
        public bool EstLue { get; set; }
        public SolidColorBrush Fond { get; set; } = new(Colors.White);
        public string Poids { get; set; } = "Normal";
        public Visibility PointVisible { get; set; } = Visibility.Collapsed;
    }

    public partial class NotificationsPage : Page
    {
        private readonly Utilisateur _user;
        private readonly NotificationService _notifService = new();

        public NotificationsPage()
        {
            InitializeComponent();
            _user = Session.UtilisateurConnecte!;
            Loaded += (s, e) => Charger();
        }

        private void Charger()
        {
            var notifications = _notifService.ObtenirToutes(_user.Id);

            var liste = notifications.Select(n => new NotificationViewModel
            {
                Id = n.Id,
                Message = n.Message,
                DateStr = FormatDate(n.DateCreation),
                EstLue = n.EstLue,
                Fond = n.EstLue
                    ? new SolidColorBrush(Colors.White)
                    : new SolidColorBrush(Color.FromRgb(255, 251, 235)),
                Poids = n.EstLue ? "Normal" : "SemiBold",
                PointVisible = n.EstLue ? Visibility.Collapsed : Visibility.Visible
            }).ToList();

            ListeNotifications.ItemsSource = liste;
            PanelVide.Visibility = liste.Count == 0
                ? Visibility.Visible
                : Visibility.Collapsed;
        }

        private string FormatDate(DateTime date)
        {
            var diff = DateTime.Now - date;
            if (diff.TotalMinutes < 1) return "À l'instant";
            if (diff.TotalMinutes < 60) return $"Il y a {(int)diff.TotalMinutes} min";
            if (diff.TotalHours < 24) return $"Il y a {(int)diff.TotalHours}h";
            if (diff.TotalDays < 7) return $"Il y a {(int)diff.TotalDays} jour(s)";
            return date.ToString("dd/MM/yyyy HH:mm");
        }

        private void BtnToutLire_Click(object sender, RoutedEventArgs e)
        {
            _notifService.MarquerToutesCommeLues(_user.Id);
            Charger();
        }
    }
}
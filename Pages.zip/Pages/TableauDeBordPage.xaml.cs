﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using PtiBoulot.Data;
using PtiBoulot.Models;
using PtiBoulot.Services;

namespace PtiBoulot.Pages
{
    public partial class TableauDeBordPage : Page
    {
        private readonly Utilisateur _user;

        public TableauDeBordPage()
        {
            InitializeComponent();
            _user = Session.UtilisateurConnecte!;
            Loaded += (s, e) => Charger();
        }

        private void Charger()
        {
            using var db = new AppDbContext();

            switch (_user.Role)
            {
                case "Admin":
                    ChargerAdmin(db);
                    break;
                case "Client":
                    ChargerClient(db);
                    break;
                case "Prestataire":
                    ChargerPrestataire(db);
                    break;
            }
        }

        private void ChargerAdmin(AppDbContext db)
        {
            TxtSoustitre.Text = "VUE ADMIN";
            TxtBienvenue.Text = $"Bienvenue, {_user.NomComplet} !";
            TxtDescription.Text = "Supervisez et administrez la plateforme P'tiBoulot";
            BtnAction.Content = "⚙  Administration";
            BtnAction.Visibility = Visibility.Visible;

            var totalOffres = db.Offres.Count();
            var utilisateurs = db.Utilisateurs.Count();
            var candidatures = db.Candidatures.Count();

            DefinirStats(
                "TOTAL OFFRES", totalOffres.ToString(), "actives",
                "UTILISATEURS", utilisateurs.ToString(), "inscrits",
                "CANDIDATURES", candidatures.ToString(), "en cours",
                "NOTE MOY.", "4.8★", "sur 5"
            );

            AjouterAction("⚡", "Accéder à l'administration", "#FEF3C7", "#92400E");
        }

        private void ChargerClient(AppDbContext db)
        {
            TxtSoustitre.Text = "TABLEAU DE BORD";
            TxtBienvenue.Text = $"Bienvenue, {_user.NomComplet} ! 👋";
            TxtDescription.Text = "Gérez vos offres et trouvez les meilleurs prestataires du Gabon";
            BtnAction.Content = "+  Nouvelle offre";
            BtnAction.Visibility = Visibility.Visible;

            var offresActives = db.Offres.Count(o => o.ClientId == _user.Id && o.Statut == "Active");
            var candidaturesRecues = db.Candidatures.Count(c => c.Offre!.ClientId == _user.Id);

            DefinirStats(
                "MES OFFRES ACTIVES", offresActives.ToString(), "en ligne",
                "MISSIONS EN COURS", "0", "actif",
                "MISSIONS TERMINÉES", "0", "actif",
                "CANDIDATURES REÇUES", candidaturesRecues.ToString(), "actif"
            );

            AjouterAction("+", "Publier une offre", "#DCFCE7", "#166534");
            AjouterAction("👤", "Trouver un prestataire", "#DBEAFE", "#1E40AF");
            AjouterAction("⭐", "Mes missions", "#FEF3C7", "#92400E");
        }

        private void ChargerPrestataire(AppDbContext db)
        {
            TxtSoustitre.Text = "TABLEAU DE BORD";
            TxtBienvenue.Text = $"Bienvenue, {_user.NomComplet} ! 👋";
            TxtDescription.Text = "Découvrez de nouvelles missions et développez votre activité";

            var offresDispo = db.Offres.Count(o => o.Statut == "Active");
            var mesCandidatures = db.Candidatures.Count(c => c.PrestataireId == _user.Id);

            DefinirStats(
                "OFFRES DISPO", offresDispo.ToString(), "disponibles",
                "MES CANDIDATURES", mesCandidatures.ToString(), "envoyées",
                "MISSIONS EN COURS", "0", "actif",
                "MISSIONS TERMINÉES", "0", "actif"
            );

            AjouterAction("🧳", "Voir les offres", "#DBEAFE", "#1E40AF");
            AjouterAction("⭐", "Mes missions", "#FEF3C7", "#92400E");
        }

        private void DefinirStats(
            string l1, string v1, string s1,
            string l2, string v2, string s2,
            string l3, string v3, string s3,
            string l4, string v4, string s4)
        {
            TxtStat1Label.Text = l1; TxtStat1Value.Text = v1; TxtStat1Sub.Text = s1;
            TxtStat2Label.Text = l2; TxtStat2Value.Text = v2; TxtStat2Sub.Text = s2;
            TxtStat3Label.Text = l3; TxtStat3Value.Text = v3; TxtStat3Sub.Text = s3;
            TxtStat4Label.Text = l4; TxtStat4Value.Text = v4; TxtStat4Sub.Text = s4;
        }

        private void AjouterAction(string icone, string label, string bgHex, string fgHex)
        {
            var bg = (SolidColorBrush)new BrushConverter().ConvertFrom(bgHex)!;
            var fg = (SolidColorBrush)new BrushConverter().ConvertFrom(fgHex)!;

            var btn = new Button
            {
                Height = 46,
                Margin = new Thickness(0, 0, 0, 8),
                Background = new SolidColorBrush(Color.FromRgb(248, 250, 252)),
                BorderBrush = new SolidColorBrush(Color.FromRgb(226, 232, 240)),
                BorderThickness = new Thickness(1),
                Cursor = System.Windows.Input.Cursors.Hand,
                HorizontalContentAlignment = HorizontalAlignment.Stretch,
                Padding = new Thickness(12, 0, 12, 0)
            };

            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var badge = new Border
            {
                Width = 28,
                Height = 28,
                CornerRadius = new CornerRadius(6),
                Background = bg,
                Margin = new Thickness(0, 0, 12, 0)
            };
            badge.Child = new TextBlock
            {
                Text = icone,
                FontSize = 13,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };

            var txt = new TextBlock
            {
                Text = label,
                FontSize = 14,
                Foreground = fg,
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetColumn(txt, 1);

            var arrow = new TextBlock
            {
                Text = "→",
                FontSize = 14,
                Foreground = new SolidColorBrush(Color.FromRgb(148, 163, 184)),
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetColumn(arrow, 2);

            grid.Children.Add(badge);
            grid.Children.Add(txt);
            grid.Children.Add(arrow);
            btn.Content = grid;

            ActionsPanel.Children.Add(btn);
        }

        private void BtnAction_Click(object sender, RoutedEventArgs e)
        {
            if (_user.Role == "Admin")
                NavigationService?.Navigate(new AdministrationPage());
            else
                NavigationService?.Navigate(new NouvelleOffrePage());
        }
    }
}
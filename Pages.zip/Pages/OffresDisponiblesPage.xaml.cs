﻿using Microsoft.EntityFrameworkCore;
using PtiBoulot.Data;
using PtiBoulot.Models;
using PtiBoulot.Services;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace PtiBoulot.Pages
{
    public class OffreViewModel
    {
        public int Id { get; set; }
        public string Titre { get; set; } = "";
        public string Description { get; set; } = "";
        public string BudgetStr { get; set; } = "";
        public string? Localisation { get; set; }
        public string? Delai { get; set; }
        public string StatutCandidature { get; set; } = "Aucune";
        public string BoutonTexte { get; set; } = "Postuler →";
        public bool BoutonActif { get; set; } = true;
        public SolidColorBrush BoutonCouleur { get; set; } = new(Color.FromRgb(59, 130, 246));
    }

    public partial class OffresDisponiblesPage : Page
    {
        private List<OffreViewModel> _toutesOffres = new();
        private readonly Utilisateur _user;

        public OffresDisponiblesPage()
        {
            InitializeComponent();
            _user = Session.UtilisateurConnecte!;
            Loaded += (s, e) => Charger();
        }

        private void Charger()
        {
            using var db = new AppDbContext();

            var offres = db.Offres
                .Where(o => o.Statut == "Active")
                .ToList();

            var mesCandidatures = db.Candidatures
                .Where(c => c.PrestataireId == _user.Id)
                .ToList();

            _toutesOffres = offres.Select(o =>
            {
                var cand = mesCandidatures.FirstOrDefault(c => c.OffreId == o.Id);
                string statut = cand?.StatutCandidature ?? "Aucune";

                string texte = statut switch
                {
                    "En attente" => "⏳ En attente",
                    "Acceptée" => "✅ Acceptée",
                    "Refusée" => "❌ Refusée",
                    _ => "Postuler →"
                };

                bool actif = statut == "Aucune";

                SolidColorBrush couleur = statut switch
                {
                    "En attente" => new SolidColorBrush(Color.FromRgb(245, 158, 11)),
                    "Acceptée" => new SolidColorBrush(Color.FromRgb(34, 197, 94)),
                    "Refusée" => new SolidColorBrush(Color.FromRgb(239, 68, 68)),
                    _ => new SolidColorBrush(Color.FromRgb(59, 130, 246))
                };

                return new OffreViewModel
                {
                    Id = o.Id,
                    Titre = o.Titre,
                    Description = o.Description,
                    BudgetStr = $"{o.Budget:N0} FCFA",
                    Localisation = o.Localisation ?? "Non précisée",
                    Delai = o.Delai ?? "Non précisé",
                    StatutCandidature = statut,
                    BoutonTexte = texte,
                    BoutonActif = actif,
                    BoutonCouleur = couleur
                };
            }).ToList();

            AfficherOffres(_toutesOffres);
        }

        private void AfficherOffres(List<OffreViewModel> liste)
        {
            ListeOffres.ItemsSource = liste;
            TxtNbOffres.Text = $"{liste.Count} offre{(liste.Count > 1 ? "s" : "")}";
            PanelVide.Visibility = liste.Count == 0
                ? Visibility.Visible
                : Visibility.Collapsed;
        }

        private void TxtRecherche_TextChanged(object sender, TextChangedEventArgs e)
        {
            var recherche = TxtRecherche.Text.Trim().ToLower();

            if (string.IsNullOrEmpty(recherche))
            {
                AfficherOffres(_toutesOffres);
                return;
            }

            var filtres = _toutesOffres
                .Where(o =>
                    o.Titre.ToLower().Contains(recherche) ||
                    o.Description.ToLower().Contains(recherche) ||
                    (o.Localisation?.ToLower().Contains(recherche) ?? false))
                .ToList();

            AfficherOffres(filtres);
        }

        private void BtnPostuler_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is int offreId)
            {
                using var db = new AppDbContext();

                // Vérifier si déjà candidaté
                var dejaCandidature = db.Candidatures
                    .Any(c => c.OffreId == offreId && c.PrestataireId == _user.Id);

                if (dejaCandidature)
                {
                    MessageBox.Show("Vous avez déjà postulé à cette offre.",
                        "Info", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                // Créer la candidature
                var candidature = new Candidature
                {
                    OffreId = offreId,
                    PrestataireId = _user.Id,
                    StatutCandidature = "En attente"
                };
                db.Candidatures.Add(candidature);
                db.SaveChanges();

                // Envoyer notification au client
                var offre = db.Offres.Find(offreId);
                if (offre != null)
                {
                    var notifService = new NotificationService();
                    notifService.Envoyer(
                        offre.ClientId,
                        $"🧑 {_user.NomComplet} a postulé à votre offre \"{offre.Titre}\""
                    );
                }

                MessageBox.Show("✅ Candidature envoyée avec succès !",
                    "Succès", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }
}
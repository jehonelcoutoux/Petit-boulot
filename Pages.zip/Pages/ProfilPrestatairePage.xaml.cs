﻿using System.Windows.Controls;
using System.Windows.Media;
using PtiBoulot.Data;
using PtiBoulot.Models;

namespace PtiBoulot.Pages
{
    public partial class ProfilPrestatairePage : Page
    {
        private readonly int _prestataireId;

        public ProfilPrestatairePage(int prestataireId)
        {
            InitializeComponent();
            _prestataireId = prestataireId;
            Loaded += (s, e) => Charger();
        }

        private void Charger()
        {
            using var db = new AppDbContext();

            var prestataire = db.Utilisateurs
                .FirstOrDefault(u => u.Id == _prestataireId);

            if (prestataire == null) return;

            // Header
            TxtAvatar.Text = prestataire.Initiales;
            TxtNom.Text = prestataire.NomComplet;
            TxtMembre.Text = $"Membre depuis {prestataire.Id}";
            TxtBio.Text = prestataire.DescriptionProfil ?? "Aucune description";
            TxtNote.Text = "4.5 ⭐";

            // Informations
            TxtVille.Text = prestataire.Ville ?? "Non renseignée";
            TxtTarif.Text = prestataire.TarifHoraire.HasValue
                ? $"{prestataire.TarifHoraire:N0} FCFA/h"
                : "Non renseigné";
            TxtTelephone.Text = prestataire.Telephone ?? "Non renseigné";
            TxtEmail.Text = prestataire.Email;

            // Compétences
            PanelCompetences.Children.Clear();
            if (!string.IsNullOrEmpty(prestataire.Competences))
            {
                var competences = prestataire.Competences.Split(',');
                foreach (var comp in competences)
                {
                    var chip = new Border
                    {
                        Background = new SolidColorBrush(Color.FromRgb(240, 253, 244)),
                        BorderBrush = new SolidColorBrush(Color.FromRgb(187, 247, 208)),
                        BorderThickness = new System.Windows.Thickness(1),
                        CornerRadius = new System.Windows.CornerRadius(20),
                        Padding = new System.Windows.Thickness(12, 5, 12, 5),
                        Margin = new System.Windows.Thickness(0, 0, 8, 8)
                    };
                    chip.Child = new TextBlock
                    {
                        Text = comp.Trim(),
                        FontSize = 12,
                        Foreground = new SolidColorBrush(Color.FromRgb(22, 101, 52))
                    };
                    PanelCompetences.Children.Add(chip);
                }
            }
        }
    }
}
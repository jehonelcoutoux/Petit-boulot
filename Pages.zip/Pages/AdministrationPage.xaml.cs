﻿using Microsoft.EntityFrameworkCore;
using PtiBoulot.Data;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.EntityFrameworkCore;

namespace PtiBoulot.Pages
{
    public class AdminViewModel
    {
        public string Initiales { get; set; } = "";
        public string Ligne1 { get; set; } = "";
        public string Ligne2 { get; set; } = "";
        public string Badge { get; set; } = "";
        public string Info { get; set; } = "";
        public SolidColorBrush AvatarBg { get; set; } = new(Colors.Gray);
        public SolidColorBrush BadgeBg { get; set; } = new(Colors.White);
        public SolidColorBrush BadgeFg { get; set; } = new(Colors.Black);
    }

    public partial class AdministrationPage : Page
    {
        public AdministrationPage()
        {
            InitializeComponent();
            Loaded += (s, e) => Charger();
        }

        private void Charger()
        {
            using var db = new AppDbContext();

            var utilisateurs = db.Utilisateurs.Count();
            var offres = db.Offres.Count();
            var candidatures = db.Candidatures.Count();

            StatUtilisateurs.Text = utilisateurs.ToString();
            StatUtilisateursSub.Text = "inscrits";
            StatOffres.Text = offres.ToString();
            StatOffresSub.Text = "publiées";
            StatCandidatures.Text = candidatures.ToString();
            StatCandidaturesSub.Text = "reçues";

            ChargerUtilisateurs(db);
        }

        private void ChargerUtilisateurs(AppDbContext db)
        {
            var data = db.Utilisateurs.ToList();

            var liste = data.Select(u => new AdminViewModel
            {
                Initiales = u.NomComplet.Length >= 2
                    ? u.NomComplet.Substring(0, 1) + u.NomComplet.Split(' ').Last().Substring(0, 1)
                    : u.NomComplet.Substring(0, 1),
                Ligne1 = u.NomComplet,
                Ligne2 = u.Email,
                Badge = u.Role,
                Info = u.Ville ?? "Gabon",
                AvatarBg = u.Role == "Admin"
                    ? new SolidColorBrush(Color.FromRgb(139, 92, 246))
                    : u.Role == "Client"
                        ? new SolidColorBrush(Color.FromRgb(34, 197, 94))
                        : new SolidColorBrush(Color.FromRgb(59, 130, 246)),
                BadgeBg = u.Role == "Admin"
                    ? new SolidColorBrush(Color.FromRgb(237, 233, 254))
                    : u.Role == "Client"
                        ? new SolidColorBrush(Color.FromRgb(220, 252, 231))
                        : new SolidColorBrush(Color.FromRgb(219, 234, 254)),
                BadgeFg = u.Role == "Admin"
                    ? new SolidColorBrush(Color.FromRgb(109, 40, 217))
                    : u.Role == "Client"
                        ? new SolidColorBrush(Color.FromRgb(22, 101, 52))
                        : new SolidColorBrush(Color.FromRgb(30, 64, 175))
            }).ToList();

            ListeAdmin.ItemsSource = liste;
        }

        private void ChargerOffres(AppDbContext db)
        {
            var data = db.Offres.ToList();

            var liste = data.Select(o => new AdminViewModel
            {
                Initiales = o.Titre.Substring(0, 1).ToUpper(),
                Ligne1 = o.Titre,
                Ligne2 = o.Localisation ?? "Gabon",
                Badge = o.Statut ?? "Active",
                Info = $"{o.Budget:N0} FCFA",
                AvatarBg = new SolidColorBrush(Color.FromRgb(34, 197, 94)),
                BadgeBg = new SolidColorBrush(Color.FromRgb(220, 252, 231)),
                BadgeFg = new SolidColorBrush(Color.FromRgb(22, 101, 52))
            }).ToList();

            ListeAdmin.ItemsSource = liste;
        }

        private void ChargerCandidatures(AppDbContext db)
        {
            var data = db.Candidatures
                .Include(c => c.Offre)
                .Include(c => c.Prestataire)
                .ToList();

            var liste = data.Select(c => new AdminViewModel
            {
                Initiales = c.Prestataire!.NomComplet.Substring(0, 1).ToUpper(),
                Ligne1 = c.Offre!.Titre,
                Ligne2 = c.Prestataire.NomComplet,
                Badge = c.StatutCandidature ?? "En attente",
                Info = "",
                AvatarBg = new SolidColorBrush(Color.FromRgb(59, 130, 246)),
                BadgeBg = new SolidColorBrush(Color.FromRgb(254, 243, 199)),
                BadgeFg = new SolidColorBrush(Color.FromRgb(146, 64, 14))
            }).ToList();

            ListeAdmin.ItemsSource = liste;
        }

        
        private void Tab_Checked(object sender, RoutedEventArgs e)
        {
            if (ListeAdmin == null) return;

            using var db = new AppDbContext();

            if (sender is RadioButton rb)
            {
                switch (rb.Tag?.ToString())
                {
                    case "Utilisateurs": ChargerUtilisateurs(db); break;
                    case "Offres": ChargerOffres(db); break;
                    case "Candidatures": ChargerCandidatures(db); break;
                }
            }
        }
    }
}
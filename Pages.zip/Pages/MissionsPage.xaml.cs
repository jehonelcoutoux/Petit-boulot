﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using PtiBoulot.Data;
using PtiBoulot.Models;
using PtiBoulot.Services;
using Microsoft.EntityFrameworkCore;

namespace PtiBoulot.Pages
{
    public class MissionViewModel
    {
        public int Id { get; set; }
        public string Titre { get; set; } = "";
        public string NomPrestataire { get; set; } = "";
        public string Statut { get; set; } = "";
        public string DateStr { get; set; } = "";
        public int PrestataireId { get; set; }
        public string TelephonePrestataire { get; set; } = "";
        public string EmailPrestataire { get; set; } = "";
        public SolidColorBrush StatutBg { get; set; } = new(Colors.White);
        public SolidColorBrush StatutFg { get; set; } = new(Colors.Black);

        // Visibilités
        public Visibility BoutonsVisible { get; set; } = Visibility.Collapsed;
        public Visibility BtnAccepterVisible { get; set; } = Visibility.Collapsed;
        public Visibility BtnRefuserVisible { get; set; } = Visibility.Collapsed;
        public Visibility BtnDemarrerVisible { get; set; } = Visibility.Collapsed;
        public Visibility BtnTerminerVisible { get; set; } = Visibility.Collapsed;
        public Visibility ContactVisible { get; set; } = Visibility.Collapsed;
        public Visibility NotationVisible { get; set; } = Visibility.Collapsed;
    }

    public partial class MissionsPage : Page
    {
        private List<MissionViewModel> _toutesMissions = new();
        private readonly Utilisateur _user;
        private readonly NotificationService _notifService = new();

        public MissionsPage()
        {
            InitializeComponent();
            _user = Session.UtilisateurConnecte!;
            Loaded += (s, e) => Charger();
        }

        private void Charger()
        {
            using var db = new AppDbContext();

            var candidatures = db.Candidatures
                .Include(c => c.Offre)
                .Include(c => c.Prestataire)
                .Where(c => _user.Role == "Client"
                    ? c.Offre!.ClientId == _user.Id
                    : c.PrestataireId == _user.Id)
                .ToList();

            _toutesMissions = candidatures.Select(c =>
            {
                var statut = c.StatutCandidature ?? "En attente";
                var estClient = _user.Role == "Client";

                var vm = new MissionViewModel
                {
                    Id = c.Id,
                    Titre = c.Offre!.Titre,
                    NomPrestataire = c.Prestataire!.NomComplet,
                    Statut = statut,
                    DateStr = "Récemment",
                    PrestataireId = c.PrestataireId,
                    TelephonePrestataire = c.Prestataire.Telephone ?? "Non renseigné",
                    EmailPrestataire = c.Prestataire.Email,

                    // Contact visible si Acceptée ou En cours
                    ContactVisible = (estClient && (statut == "Acceptée" || statut == "En cours"))
                        ? Visibility.Visible : Visibility.Collapsed,

                    // Boutons visibles selon statut et rôle
                    BoutonsVisible = estClient && statut != "Terminée" && statut != "Refusée"
                        ? Visibility.Visible : Visibility.Collapsed,

                    BtnAccepterVisible = estClient && statut == "En attente"
                        ? Visibility.Visible : Visibility.Collapsed,
                    BtnRefuserVisible = estClient && statut == "En attente"
                        ? Visibility.Visible : Visibility.Collapsed,
                    BtnDemarrerVisible = estClient && statut == "Acceptée"
                        ? Visibility.Visible : Visibility.Collapsed,
                    BtnTerminerVisible = estClient && statut == "En cours"
                        ? Visibility.Visible : Visibility.Collapsed,

                    // Notation visible si Terminée et pas encore notée
                    NotationVisible = estClient && statut == "Terminée"
                        ? Visibility.Visible : Visibility.Collapsed,
                };

                AppliquerCouleurStatut(vm);
                return vm;
            }).ToList();

            AfficherMissions(_toutesMissions);
        }

        private void AppliquerCouleurStatut(MissionViewModel m)
        {
            switch (m.Statut)
            {
                case "En attente":
                    m.StatutBg = new SolidColorBrush(Color.FromRgb(254, 243, 199));
                    m.StatutFg = new SolidColorBrush(Color.FromRgb(146, 64, 14));
                    break;
                case "Acceptée":
                    m.StatutBg = new SolidColorBrush(Color.FromRgb(219, 234, 254));
                    m.StatutFg = new SolidColorBrush(Color.FromRgb(30, 64, 175));
                    break;
                case "En cours":
                    m.StatutBg = new SolidColorBrush(Color.FromRgb(220, 252, 231));
                    m.StatutFg = new SolidColorBrush(Color.FromRgb(22, 101, 52));
                    break;
                case "Terminée":
                    m.StatutBg = new SolidColorBrush(Color.FromRgb(241, 245, 249));
                    m.StatutFg = new SolidColorBrush(Color.FromRgb(100, 116, 139));
                    break;
                case "Refusée":
                    m.StatutBg = new SolidColorBrush(Color.FromRgb(254, 226, 226));
                    m.StatutFg = new SolidColorBrush(Color.FromRgb(185, 28, 28));
                    break;
                default:
                    m.StatutBg = new SolidColorBrush(Color.FromRgb(241, 245, 249));
                    m.StatutFg = new SolidColorBrush(Color.FromRgb(100, 116, 139));
                    break;
            }
        }

        private void AfficherMissions(List<MissionViewModel> liste)
        {
            if (ListeMissions == null || PanelVide == null) return;
            ListeMissions.ItemsSource = liste;
            PanelVide.Visibility = liste.Count == 0
                ? Visibility.Visible
                : Visibility.Collapsed;
        }

        private void Tab_Checked(object sender, RoutedEventArgs e)
        {
            if (_toutesMissions == null) return;
            if (sender is RadioButton rb)
            {
                var filtered = rb.Tag?.ToString() switch
                {
                    "EnAttente" => _toutesMissions.Where(m => m.Statut == "En attente").ToList(),
                    "EnCours" => _toutesMissions.Where(m => m.Statut == "En cours").ToList(),
                    "Terminées" => _toutesMissions.Where(m => m.Statut == "Terminée").ToList(),
                    _ => _toutesMissions
                };
                AfficherMissions(filtered);
            }
        }

        private void BtnAccepter_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is int id)
                ChangerStatut(id, "Acceptée");
        }

        private void BtnRefuser_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is int id)
                ChangerStatut(id, "Refusée");
        }

        private void BtnDemarrer_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is int id)
                ChangerStatut(id, "En cours");
        }

        private void BtnTerminer_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is int id)
                ChangerStatut(id, "Terminée");
        }

        private void ChangerStatut(int candidatureId, string nouveauStatut)
        {
            using var db = new AppDbContext();

            var candidature = db.Candidatures
                .Include(c => c.Offre)
                .FirstOrDefault(c => c.Id == candidatureId);

            if (candidature == null) return;

            candidature.StatutCandidature = nouveauStatut;
            db.SaveChanges();

            string msg = nouveauStatut switch
            {
                "Acceptée" => $"✅ Votre candidature pour \"{candidature.Offre!.Titre}\" a été acceptée !",
                "Refusée" => $"❌ Votre candidature pour \"{candidature.Offre!.Titre}\" a été refusée.",
                "En cours" => $"▶ La mission \"{candidature.Offre!.Titre}\" a démarré !",
                "Terminée" => $"🏁 La mission \"{candidature.Offre!.Titre}\" est terminée.",
                _ => ""
            };

            if (!string.IsNullOrEmpty(msg))
                _notifService.Envoyer(candidature.PrestataireId, msg);

            Charger();
        }

        private void BtnNoter_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is int candidatureId)
            {
                // Récupérer la note et le commentaire
                var parent = btn.Parent as StackPanel;
                var panel = parent?.Parent as Border;
                var container = panel?.Parent as StackPanel;

                // Chercher ComboBox et TextBox dans le panel notation
                var cmbNote = FindChild<ComboBox>(panel, "CmbNote");
                var txtCommentaire = FindChild<TextBox>(panel, "TxtCommentaire");

                int note = 5;
                if (cmbNote?.SelectedIndex >= 0)
                    note = cmbNote.SelectedIndex + 1;

                string commentaire = txtCommentaire?.Text ?? "";

                using var db = new AppDbContext();
                var candidature = db.Candidatures
                    .Include(c => c.Offre)
                    .FirstOrDefault(c => c.Id == candidatureId);

                if (candidature == null) return;

                // Sauvegarder la note dans une table Avis (à créer) ou en notification
                _notifService.Envoyer(
                    candidature.PrestataireId,
                    $"⭐ Vous avez reçu une note de {note}/5 pour la mission \"{candidature.Offre!.Titre}\". Commentaire : {commentaire}"
                );

                MessageBox.Show("✅ Note envoyée avec succès !",
                    "Merci", MessageBoxButton.OK, MessageBoxImage.Information);

                Charger();
            }
        }

        private T? FindChild<T>(DependencyObject? parent, string name) where T : FrameworkElement
        {
            if (parent == null) return null;
            for (int i = 0; i < System.Windows.Media.VisualTreeHelper.GetChildrenCount(parent); i++)
            {
                var child = System.Windows.Media.VisualTreeHelper.GetChild(parent, i);
                if (child is T t && t.Name == name) return t;
                var result = FindChild<T>(child, name);
                if (result != null) return result;
            }
            return null;
        }
    }
}
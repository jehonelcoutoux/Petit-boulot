﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using PtiBoulot.Data;
using PtiBoulot.Models;
using PtiBoulot.Services;

namespace PtiBoulot.Pages
{
    public partial class ProfilPage : Page
    {
        private readonly Utilisateur _user;

        public ProfilPage()
        {
            InitializeComponent();
            _user = Session.UtilisateurConnecte!;
            Loaded += (s, e) => Charger();
        }

        private void Charger()
        {
            // Header
            TxtAvatar.Text = _user.Initiales;
            TxtNomHeader.Text = _user.NomComplet;
            TxtRoleHeader.Text = _user.Role;

            BadgeRole.Background = _user.Role switch
            {
                "Admin" => new SolidColorBrush(Color.FromRgb(237, 233, 254)),
                "Client" => new SolidColorBrush(Color.FromRgb(220, 252, 231)),
                "Prestataire" => new SolidColorBrush(Color.FromRgb(219, 234, 254)),
                _ => new SolidColorBrush(Color.FromRgb(241, 245, 249))
            };
            TxtRoleHeader.Foreground = _user.Role switch
            {
                "Admin" => new SolidColorBrush(Color.FromRgb(109, 40, 217)),
                "Client" => new SolidColorBrush(Color.FromRgb(22, 101, 52)),
                "Prestataire" => new SolidColorBrush(Color.FromRgb(30, 64, 175)),
                _ => new SolidColorBrush(Color.FromRgb(100, 116, 139))
            };

            AvatarBorder.Background = _user.Role switch
            {
                "Admin" => new SolidColorBrush(Color.FromRgb(139, 92, 246)),
                "Client" => new SolidColorBrush(Color.FromRgb(34, 197, 94)),
                "Prestataire" => new SolidColorBrush(Color.FromRgb(59, 130, 246)),
                _ => new SolidColorBrush(Color.FromRgb(100, 116, 139))
            };

            // Champs
            TxtNom.Text = _user.NomComplet;
            TxtEmail.Text = _user.Email;
            TxtTelephone.Text = _user.Telephone ?? "";
            TxtVille.Text = _user.Ville ?? "";

            // Champs prestataire seulement
            if (_user.Role == "Prestataire")
            {
                PanelBio.Visibility = Visibility.Visible;
                TxtBio.Text = _user.DescriptionProfil ?? "";
                TxtCompetences.Text = _user.Competences ?? "";
                TxtTarif.Text = _user.TarifHoraire?.ToString() ?? "";
            }
            else
            {
                PanelBio.Visibility = Visibility.Collapsed;
            }
        }

        private void BtnEnregistrer_Click(object sender, RoutedEventArgs e)
        {
            TxtErreur.Visibility = Visibility.Collapsed;
            TxtSucces.Visibility = Visibility.Collapsed;

            if (string.IsNullOrWhiteSpace(TxtNom.Text))
            {
                TxtErreur.Text = "Le nom est obligatoire.";
                TxtErreur.Visibility = Visibility.Visible;
                return;
            }

            if (string.IsNullOrWhiteSpace(TxtEmail.Text))
            {
                TxtErreur.Text = "L'email est obligatoire.";
                TxtErreur.Visibility = Visibility.Visible;
                return;
            }

            try
            {
                using var db = new AppDbContext();
                var user = db.Utilisateurs.Find(_user.Id);
                if (user == null) return;

                user.NomComplet = TxtNom.Text.Trim();
                user.Email = TxtEmail.Text.Trim();
                user.Telephone = TxtTelephone.Text.Trim();
                user.Ville = TxtVille.Text.Trim();

                if (_user.Role == "Prestataire")
                {
                    user.DescriptionProfil = TxtBio.Text.Trim();
                    user.Competences = TxtCompetences.Text.Trim();
                    if (decimal.TryParse(TxtTarif.Text, out decimal tarif))
                        user.TarifHoraire = tarif;
                }

                db.SaveChanges();

                // Mettre à jour la session
                Session.UtilisateurConnecte!.NomComplet = user.NomComplet;
                Session.UtilisateurConnecte.Email = user.Email;
                Session.UtilisateurConnecte.Telephone = user.Telephone;
                Session.UtilisateurConnecte.Ville = user.Ville;

                TxtNomHeader.Text = user.NomComplet;
                TxtSucces.Text = "✅ Profil mis à jour avec succès !";
                TxtSucces.Visibility = Visibility.Visible;
            }
            catch (Exception ex)
            {
                TxtErreur.Text = $"Erreur : {ex.Message}";
                TxtErreur.Visibility = Visibility.Visible;
            }
        }

        private void BtnChangerMdp_Click(object sender, RoutedEventArgs e)
        {
            TxtErreurMdp.Visibility = Visibility.Collapsed;
            TxtSuccesMdp.Visibility = Visibility.Collapsed;

            var actuel = TxtMdpActuel.Password;
            var nouveau = TxtNouveauMdp.Password;
            var confirm = TxtConfirmMdp.Password;

            if (string.IsNullOrEmpty(actuel) || string.IsNullOrEmpty(nouveau))
            {
                TxtErreurMdp.Text = "Veuillez remplir tous les champs.";
                TxtErreurMdp.Visibility = Visibility.Visible;
                return;
            }

            if (nouveau != confirm)
            {
                TxtErreurMdp.Text = "Les mots de passe ne correspondent pas.";
                TxtErreurMdp.Visibility = Visibility.Visible;
                return;
            }

            if (nouveau.Length < 6)
            {
                TxtErreurMdp.Text = "Le mot de passe doit contenir au moins 6 caractères.";
                TxtErreurMdp.Visibility = Visibility.Visible;
                return;
            }

            try
            {
                using var db = new AppDbContext();
                var user = db.Utilisateurs.Find(_user.Id);
                if (user == null) return;

                // Vérifier mot de passe actuel
                bool mdpOk = false;
                try
                {
                    mdpOk = BCrypt.Net.BCrypt.Verify(actuel, user.MotDePasse);
                }
                catch
                {
                    mdpOk = actuel == user.MotDePasse;
                }

                if (!mdpOk)
                {
                    TxtErreurMdp.Text = "Mot de passe actuel incorrect.";
                    TxtErreurMdp.Visibility = Visibility.Visible;
                    return;
                }

                user.MotDePasse = BCrypt.Net.BCrypt.HashPassword(nouveau);
                db.SaveChanges();

                TxtMdpActuel.Clear();
                TxtNouveauMdp.Clear();
                TxtConfirmMdp.Clear();

                TxtSuccesMdp.Text = "✅ Mot de passe changé avec succès !";
                TxtSuccesMdp.Visibility = Visibility.Visible;
            }
            catch (Exception ex)
            {
                TxtErreurMdp.Text = $"Erreur : {ex.Message}";
                TxtErreurMdp.Visibility = Visibility.Visible;
            }
        }
    }
}
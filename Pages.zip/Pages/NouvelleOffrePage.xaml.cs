﻿using System.Windows;
using System.Windows.Controls;
using PtiBoulot.Data;
using PtiBoulot.Models;
using PtiBoulot.Services;

namespace PtiBoulot.Pages
{
    public partial class NouvelleOffrePage : Page
    {
        private readonly Utilisateur _user;

        public NouvelleOffrePage()
        {
            InitializeComponent();
            _user = Session.UtilisateurConnecte!;
        }

        private void BtnPublier_Click(object sender, RoutedEventArgs e)
        {
            TxtErreur.Visibility = Visibility.Collapsed;
            TxtSucces.Visibility = Visibility.Collapsed;

            // Validation
            if (string.IsNullOrWhiteSpace(TxtTitre.Text))
            {
                TxtErreur.Text = "Le titre est obligatoire.";
                TxtErreur.Visibility = Visibility.Visible;
                return;
            }
            if (string.IsNullOrWhiteSpace(TxtDescription.Text))
            {
                TxtErreur.Text = "La description est obligatoire.";
                TxtErreur.Visibility = Visibility.Visible;
                return;
            }
            if (!decimal.TryParse(TxtBudget.Text, out decimal budget) || budget <= 0)
            {
                TxtErreur.Text = "Veuillez entrer un budget valide.";
                TxtErreur.Visibility = Visibility.Visible;
                return;
            }
            if (string.IsNullOrWhiteSpace(TxtLocalisation.Text))
            {
                TxtErreur.Text = "La localisation est obligatoire.";
                TxtErreur.Visibility = Visibility.Visible;
                return;
            }

            try
            {
                using var db = new AppDbContext();

                var offre = new Offre
                {
                    Titre = TxtTitre.Text.Trim(),
                    Description = TxtDescription.Text.Trim(),
                    Budget = budget,
                    Delai = TxtDelai.Text.Trim(),
                    Localisation = TxtLocalisation.Text.Trim(),
                    Statut = "Active",
                    ClientId = _user.Id
                };

                db.Offres.Add(offre);
                db.SaveChanges();

                TxtSucces.Text = "✅ Offre publiée avec succès !";
                TxtSucces.Visibility = Visibility.Visible;

                // Vider le formulaire
                TxtTitre.Text = "";
                TxtDescription.Text = "";
                TxtBudget.Text = "";
                TxtDelai.Text = "";
                TxtLocalisation.Text = "";
            }
            catch (Exception ex)
            {
                TxtErreur.Text = $"Erreur : {ex.Message}";
                TxtErreur.Visibility = Visibility.Visible;
            }
        }

        private void BtnAnnuler_Click(object sender, RoutedEventArgs e)
        {
            NavigationService?.Navigate(new TableauDeBordPage());
        }
    }
}
﻿using System.Windows;
using System.Windows.Controls;
using PtiBoulot.Data;
using PtiBoulot.Models;

namespace PtiBoulot.Pages
{
    public class PrestataireViewModel
    {
        public int Id { get; set; }
        public string NomComplet { get; set; } = "";
        public string Initiales { get; set; } = "";
        public string? Competences { get; set; }
        public string? Ville { get; set; }
        public string TarifStr { get; set; } = "";
    }

    public partial class PrestatairesPage : Page
    {
        private List<PrestataireViewModel> _tousLesPrestataires = new();

        public PrestatairesPage()
        {
            InitializeComponent();
            Loaded += (s, e) => Charger();
        }

        private void Charger()
        {
            using var db = new AppDbContext();

            _tousLesPrestataires = db.Utilisateurs
                .Where(u => u.Role == "Prestataire")
                .Select(u => new PrestataireViewModel
                {
                    Id = u.Id,
                    NomComplet = u.NomComplet,
                    Initiales = u.NomComplet.Length >= 2
                        ? u.NomComplet.Substring(0, 1) + u.NomComplet.Split(' ').Last().Substring(0, 1)
                        : u.NomComplet.Substring(0, 1),
                    Competences = u.Competences,
                    Ville = u.Ville,
                    TarifStr = u.TarifHoraire.HasValue
                        ? $"{u.TarifHoraire:N0} FCFA/h"
                        : "Tarif non défini"
                })
                .ToList();

            AfficherResultats(_tousLesPrestataires);
        }

        private void AfficherResultats(List<PrestataireViewModel> liste)
        {
            ListePrestataires.ItemsSource = liste;
            TxtNbResultats.Text = $"{liste.Count} prestataire{(liste.Count > 1 ? "s" : "")}";

            PanelVide.Visibility = liste.Count == 0
                ? Visibility.Visible
                : Visibility.Collapsed;
        }

        private void TxtRecherche_TextChanged(object sender, TextChangedEventArgs e)
        {
            var recherche = TxtRecherche.Text.Trim().ToLower();

            if (string.IsNullOrEmpty(recherche))
            {
                AfficherResultats(_tousLesPrestataires);
                return;
            }

            var filtres = _tousLesPrestataires
                .Where(p =>
                    p.NomComplet.ToLower().Contains(recherche) ||
                    (p.Competences?.ToLower().Contains(recherche) ?? false) ||
                    (p.Ville?.ToLower().Contains(recherche) ?? false))
                .ToList();

            AfficherResultats(filtres);
        }

        private void BtnVoir_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is int id)
            {
                NavigationService?.Navigate(new ProfilPrestatairePage(id));
            }
        }
    }
}
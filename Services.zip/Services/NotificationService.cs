﻿using Microsoft.EntityFrameworkCore;
using PtiBoulot.Data;
using PtiBoulot.Models;

namespace PtiBoulot.Services
{
    public class NotificationService
    {
        public void Envoyer(int utilisateurId, string message)
        {
            using var db = new AppDbContext();
            db.Notifications.Add(new Notification
            {
                UtilisateurId = utilisateurId,
                Message = message,
                EstLue = false,
                DateCreation = DateTime.Now
            });
            db.SaveChanges();
        }

        public List<Notification> ObtenirNonLues(int utilisateurId)
        {
            using var db = new AppDbContext();
            return db.Notifications
                .Where(n => n.UtilisateurId == utilisateurId && !n.EstLue)
                .OrderByDescending(n => n.DateCreation)
                .ToList();
        }

        public List<Notification> ObtenirToutes(int utilisateurId)
        {
            using var db = new AppDbContext();
            return db.Notifications
                .Where(n => n.UtilisateurId == utilisateurId)
                .OrderByDescending(n => n.DateCreation)
                .ToList();
        }

        public void MarquerCommeLue(int notificationId)
        {
            using var db = new AppDbContext();
            var notif = db.Notifications.Find(notificationId);
            if (notif != null)
            {
                notif.EstLue = true;
                db.SaveChanges();
            }
        }

        public void MarquerToutesCommeLues(int utilisateurId)
        {
            using var db = new AppDbContext();
            var notifs = db.Notifications
                .Where(n => n.UtilisateurId == utilisateurId && !n.EstLue)
                .ToList();
            foreach (var n in notifs)
                n.EstLue = true;
            db.SaveChanges();
        }

        public int CompterNonLues(int utilisateurId)
        {
            using var db = new AppDbContext();
            return db.Notifications
                .Count(n => n.UtilisateurId == utilisateurId && !n.EstLue);
        }
    }
}
﻿using Microsoft.EntityFrameworkCore;
using PtiBoulot.Data;
using PtiBoulot.Models;

namespace PtiBoulot.Services
{
    public static class Session
    {
        public static Utilisateur? UtilisateurConnecte { get; set; }
        public static bool EstConnecte => UtilisateurConnecte != null;
    }

    public class AuthService
    {
        public (bool Succes, string Message, Utilisateur? Utilisateur) Connexion(string email, string motDePasse)
        {
            using var db = new AppDbContext();

            var utilisateur = db.Utilisateurs
                .FirstOrDefault(u => u.Email == email);

            if (utilisateur == null)
                return (false, "Email introuvable.", null);

            // Vérifie en texte brut (pour les comptes déjà créés)
            bool motDePasseOk = false;
            try
            {
                motDePasseOk = BCrypt.Net.BCrypt.Verify(motDePasse, utilisateur.MotDePasse);
            }
            catch
            {
                // Mot de passe stocké en texte brut
                motDePasseOk = (motDePasse == utilisateur.MotDePasse);
            }

            if (!motDePasseOk)
                return (false, "Mot de passe incorrect.", null);

            Session.UtilisateurConnecte = utilisateur;
            return (true, "Connexion réussie.", utilisateur);
        }

        public void Deconnexion()
        {
            Session.UtilisateurConnecte = null;
        }
    }
}